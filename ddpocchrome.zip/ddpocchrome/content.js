// 在标签页的 contentScript.js 文件中
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {

  //document获取网页全部内容,包含html标签之外的注释
  function getAllContent(node,fullContent) {
      for (var i = 0; i < node.childNodes.length; i++) {
          var child = node.childNodes[i];
          if (child.nodeType === 8) { // 注释节点
              fullContent += "<!--" + child.nodeValue + "-->";
          } else {
              fullContent += child.outerHTML || child.nodeValue;
              if (child.nodeType === 1) { // 元素节点
                  getAllContent(child,fullContent);
              }
          }
      }
      return fullContent
  }

  if (request.action === 'get_page_content') {
    // 获取网页内容
    var pageContent = document.documentElement.outerHTML;
    var pageContent = getAllContent(document,"");
    var title = document.title;
    // 从DOM中获取favicon元素
    var faviconElement = document.querySelector("link[rel*='icon']");
    // 获取favicon的链接
    var iconUrl = faviconElement ? faviconElement.href : null;
    // 处理相对路径
    if (iconUrl && !iconUrl.startsWith("http")) {
        var base = document.baseURI;
        iconUrl = new URL(iconUrl, base).href;
    }
    // 将网页内容发送回 background.js
    sendResponse({ pageContent: pageContent,title: title,iconUrl: iconUrl});
  }
});