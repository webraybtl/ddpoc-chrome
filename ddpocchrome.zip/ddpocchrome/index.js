function Sleep (time) {
	return new Promise((resolve) => setTimeout(resolve, time));
}
//计算md5
function stringChangeMd5(string){function RotateLeft(lValue,iShiftBits){return lValue<<iShiftBits|lValue>>>32-iShiftBits}function AddUnsigned(lX,lY){var lX4,lY4,lX8,lY8,lResult;return lX8=2147483648&lX,lY8=2147483648&lY,lResult=(1073741823&lX)+(1073741823&lY),(lX4=1073741824&lX)&(lY4=1073741824&lY)?2147483648^lResult^lX8^lY8:lX4|lY4?1073741824&lResult?3221225472^lResult^lX8^lY8:1073741824^lResult^lX8^lY8:lResult^lX8^lY8}function FF(a,b,c,d,x,s,ac){return a=AddUnsigned(a,AddUnsigned(AddUnsigned(function(x,y,z){return x&y|~x&z}(b,c,d),x),ac)),AddUnsigned(RotateLeft(a,s),b)}function GG(a,b,c,d,x,s,ac){return a=AddUnsigned(a,AddUnsigned(AddUnsigned(function(x,y,z){return x&z|y&~z}(b,c,d),x),ac)),AddUnsigned(RotateLeft(a,s),b)}function HH(a,b,c,d,x,s,ac){return a=AddUnsigned(a,AddUnsigned(AddUnsigned(function(x,y,z){return x^y^z}(b,c,d),x),ac)),AddUnsigned(RotateLeft(a,s),b)}function II(a,b,c,d,x,s,ac){return a=AddUnsigned(a,AddUnsigned(AddUnsigned(function(x,y,z){return y^(x|~z)}(b,c,d),x),ac)),AddUnsigned(RotateLeft(a,s),b)}function WordToHex(lValue){var lCount,WordToHexValue="",WordToHexValue_temp="";for(lCount=0;lCount<=3;lCount++)WordToHexValue+=(WordToHexValue_temp="0"+(lValue>>>8*lCount&255).toString(16)).substr(WordToHexValue_temp.length-2,2);return WordToHexValue}var k,AA,BB,CC,DD,a,b,c,d,x=Array();for(string=function(string){string=string.replace(/\r\n/g,"\n");for(var utftext="",n=0;n<string.length;n++){var c=string.charCodeAt(n);c<128?utftext+=String.fromCharCode(c):c>127&&c<2048?(utftext+=String.fromCharCode(c>>6|192),utftext+=String.fromCharCode(63&c|128)):(utftext+=String.fromCharCode(c>>12|224),utftext+=String.fromCharCode(c>>6&63|128),utftext+=String.fromCharCode(63&c|128))}return utftext}(string),x=function(string){for(var lWordCount,lMessageLength=string.length,lNumberOfWords_temp1=lMessageLength+8,lNumberOfWords=16*((lNumberOfWords_temp1-lNumberOfWords_temp1%64)/64+1),lWordArray=Array(lNumberOfWords-1),lBytePosition=0,lByteCount=0;lByteCount<lMessageLength;)lBytePosition=lByteCount%4*8,lWordArray[lWordCount=(lByteCount-lByteCount%4)/4]=lWordArray[lWordCount]|string.charCodeAt(lByteCount)<<lBytePosition,lByteCount++;return lBytePosition=lByteCount%4*8,lWordArray[lWordCount=(lByteCount-lByteCount%4)/4]=lWordArray[lWordCount]|128<<lBytePosition,lWordArray[lNumberOfWords-2]=lMessageLength<<3,lWordArray[lNumberOfWords-1]=lMessageLength>>>29,lWordArray}(string),a=1732584193,b=4023233417,c=2562383102,d=271733878,k=0;k<x.length;k+=16)AA=a,BB=b,CC=c,DD=d,a=FF(a,b,c,d,x[k+0],7,3614090360),d=FF(d,a,b,c,x[k+1],12,3905402710),c=FF(c,d,a,b,x[k+2],17,606105819),b=FF(b,c,d,a,x[k+3],22,3250441966),a=FF(a,b,c,d,x[k+4],7,4118548399),d=FF(d,a,b,c,x[k+5],12,1200080426),c=FF(c,d,a,b,x[k+6],17,2821735955),b=FF(b,c,d,a,x[k+7],22,4249261313),a=FF(a,b,c,d,x[k+8],7,1770035416),d=FF(d,a,b,c,x[k+9],12,2336552879),c=FF(c,d,a,b,x[k+10],17,4294925233),b=FF(b,c,d,a,x[k+11],22,2304563134),a=FF(a,b,c,d,x[k+12],7,1804603682),d=FF(d,a,b,c,x[k+13],12,4254626195),c=FF(c,d,a,b,x[k+14],17,2792965006),a=GG(a,b=FF(b,c,d,a,x[k+15],22,1236535329),c,d,x[k+1],5,4129170786),d=GG(d,a,b,c,x[k+6],9,3225465664),c=GG(c,d,a,b,x[k+11],14,643717713),b=GG(b,c,d,a,x[k+0],20,3921069994),a=GG(a,b,c,d,x[k+5],5,3593408605),d=GG(d,a,b,c,x[k+10],9,38016083),c=GG(c,d,a,b,x[k+15],14,3634488961),b=GG(b,c,d,a,x[k+4],20,3889429448),a=GG(a,b,c,d,x[k+9],5,568446438),d=GG(d,a,b,c,x[k+14],9,3275163606),c=GG(c,d,a,b,x[k+3],14,4107603335),b=GG(b,c,d,a,x[k+8],20,1163531501),a=GG(a,b,c,d,x[k+13],5,2850285829),d=GG(d,a,b,c,x[k+2],9,4243563512),c=GG(c,d,a,b,x[k+7],14,1735328473),a=HH(a,b=GG(b,c,d,a,x[k+12],20,2368359562),c,d,x[k+5],4,4294588738),d=HH(d,a,b,c,x[k+8],11,2272392833),c=HH(c,d,a,b,x[k+11],16,1839030562),b=HH(b,c,d,a,x[k+14],23,4259657740),a=HH(a,b,c,d,x[k+1],4,2763975236),d=HH(d,a,b,c,x[k+4],11,1272893353),c=HH(c,d,a,b,x[k+7],16,4139469664),b=HH(b,c,d,a,x[k+10],23,3200236656),a=HH(a,b,c,d,x[k+13],4,681279174),d=HH(d,a,b,c,x[k+0],11,3936430074),c=HH(c,d,a,b,x[k+3],16,3572445317),b=HH(b,c,d,a,x[k+6],23,76029189),a=HH(a,b,c,d,x[k+9],4,3654602809),d=HH(d,a,b,c,x[k+12],11,3873151461),c=HH(c,d,a,b,x[k+15],16,530742520),a=II(a,b=HH(b,c,d,a,x[k+2],23,3299628645),c,d,x[k+0],6,4096336452),d=II(d,a,b,c,x[k+7],10,1126891415),c=II(c,d,a,b,x[k+14],15,2878612391),b=II(b,c,d,a,x[k+5],21,4237533241),a=II(a,b,c,d,x[k+12],6,1700485571),d=II(d,a,b,c,x[k+3],10,2399980690),c=II(c,d,a,b,x[k+10],15,4293915773),b=II(b,c,d,a,x[k+1],21,2240044497),a=II(a,b,c,d,x[k+8],6,1873313359),d=II(d,a,b,c,x[k+15],10,4264355552),c=II(c,d,a,b,x[k+6],15,2734768916),b=II(b,c,d,a,x[k+13],21,1309151649),a=II(a,b,c,d,x[k+4],6,4149444226),d=II(d,a,b,c,x[k+11],10,3174756917),c=II(c,d,a,b,x[k+2],15,718787259),b=II(b,c,d,a,x[k+9],21,3951481745),a=AddUnsigned(a,AA),b=AddUnsigned(b,BB),c=AddUnsigned(c,CC),d=AddUnsigned(d,DD);return(WordToHex(a)+WordToHex(b)+WordToHex(c)+WordToHex(d)).toLowerCase()}
//计算icon的md5
function fetchRemoteIconContentSynchronously(iconUrl){const xhr=new XMLHttpRequest;if(xhr.open("GET",iconUrl,!1),xhr.send(),200===xhr.status)return stringChangeMd5(xhr.responseText);throw new Error("Failed to fetch remote icon. Status: "+xhr.status)}
$(async function(){
	var token_bai=""
	var zhiwen=$("#zhiwen")
	var poc=$("#poc")
	var loading='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: rgb(255, 255, 255); display: block; shape-rendering: auto;" width="60px" height="60px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid"><path fill="none" stroke="#93dbe9" stroke-width="6" stroke-dasharray="64.14723205566406 64.14723205566406" d="M24.3 30C11.4 30 5 43.3 5 50s6.4 20 19.3 20c19.3 0 32.1-40 51.4-40 C88.6 30 95 43.3 95 50s-6.4 20-19.3 20C56.4 70 43.6 30 24.3 30z" stroke-linecap="round" style="transform:scale(0.8);transform-origin:50px 50px"><animate attributeName="stroke-dashoffset" repeatCount="indefinite" dur="1s" keyTimes="0;1" values="0;256.58892822265625"></animate></path></svg>'
	
	// 获取token数据，在input展示
	chrome.storage.sync.get(['ddpoc_chrome_token'], function(result) {
		if (result.ddpoc_chrome_token) {
			var token=result.ddpoc_chrome_token
			var temptoken=token.substring(0, 15) + '*'.repeat(10) + token.substring(25);
			$(".token").val(temptoken)
			token_bai=result.ddpoc_chrome_token.trim();
		}
	});
	if (token_bai=="") {
	 	await Sleep(500);
	}
	function filterUrlCharacters(url) {
	  // 使用正则表达式过滤，只保留字母、数字和下划线
	  return url.replace(/[^a-zA-Z0-9_]/g, '');
	}
	$(".save-token").click(function(){
		var token=$(".token").val()
		if (token=="") {
			alert("请填写你的token在提交")
			return false
		}
		// 将数据保存到 Chrome 同步存储
		chrome.storage.sync.set({ ddpoc_chrome_token: token }, function() {
		  	// console.log('token保存成功');
		  	location.reload()
			token_bai=token
		});
		return false
	})
	chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
		if (token_bai=="") {
			zhiwen.html("<center style='color:red'>需要提交保存token后，重新打开插件才生效</center>")
			return true
		}
		$(".data-c").show()
		zhiwen.html(loading)
		poc.html(loading)
		// 获取当前活动标签页的信息
	  	var activeTab = tabs[0];
	  	var web_key=filterUrlCharacters(activeTab.url)
    	// console.log(web_key)
	  	// 使用chrome.tabs.sendMessage向当前标签页发送消息
	  	chrome.tabs.sendMessage(activeTab.id, { action: 'get_page_content' }, function(response) {
	  		//检查缓存
	  		chrome.storage.local.get([web_key+"zhiwen_html",web_key+"poc_html"], function(result) {
	  			zhiwenkey=web_key+"zhiwen_html"
	  			pockey=web_key+"poc_html"
	  			if (result[zhiwenkey] && result[pockey]) {
	  				// console.log(result[pockey])
	  				// console.log(result[zhiwenkey])
		    		zhiwen.html(result[zhiwenkey])
		    		poc.html(result[pockey])
	  				return true
	  			}else{
				    // response包含了来自标签页的响应
			  		var body=""
			  		var iconUrl=""
			  		var iconhash=""
			  		var header=""
			  		var title=""
				    if (response) {
				    	body=response.pageContent
				    	title=response.title
				    	iconUrl=response.iconUrl
				    } else {
				    	zhiwen.html("<center style='color:red'>分析失败，关闭插件，刷新网页，在打开插件重试</center>")
						poc.html("<center style='color:red'>分析失败，关闭插件，刷新网页，在打开插件重试</center>")
				      	return 
				    }
			      	var req = new XMLHttpRequest();
			      	req.open('GET', activeTab.url, false);
			      	req.send(null);
			  		header=req.getAllResponseHeaders()
			      	if (iconUrl) {
			      		// iconhash=fetchRemoteIconContentSynchronously(iconUrl)
			      	}
			      	// 使用jQuery的$.ajax方法发起POST请求
					var postData = {
					  	version: 0.1,
					  	url: activeTab.url,
					  	iconhash: iconhash,
					  	token: token_bai,
					  	header: header,
					  	title: title,
					  	body: body
					};
					console.log(JSON.stringify(postData))
			      	$.ajax({
						url: "https://www.ddpoc.com/chrome",
						// url: "http://127.0.0.1:5008/chrome",
						type: 'POST',
						contentType: 'application/json',  // 设置请求头的Content-Type
						data: JSON.stringify(postData),  // 将数据转换为JSON字符串
						success: function(data) {
							// console.log(JSON.stringify(postData))
							data=JSON.parse(data);
							console.log(data)
							if (data['status']==1) {
				    			zhiwen.html("<center style='color:red'>"+data.msg+"</center>")
				    			poc.html("")
								return true
							}
							var zhiwen_html=""
							var poc_html=""
							$.each(data['data']['target'], function (index, value) {
								if (value['list'].length>0) {
								    zhiwen_html+="<h6>"+value['name']+"："
									$.each(value['list'], function (index1, value1) {
								    	zhiwen_html+='<span class="badge bg-primary ic">'+value1+'</span>'
									})
								    zhiwen_html+="</h6>"
								}
							});
							zhiwen_html=zhiwen_html==""?"<center>无指纹</center>":zhiwen_html
				    		zhiwen.html(zhiwen_html)
				    		var i=0
				    		$.each(data['data']['pocs'], function (index, value) {
						        i++
						        if (i>20) {
						        	poc_html+='<small class="d-block text-center mt-3"><a href="https://www.ddpoc.com" target="_blank">查看更多</a></small>'
						        	return false;
						        }
					        	poc_html+='<div class="d-flex text-muted pt-3 to-ddpoc">'
					            +'  <span class="badge text-bg-danger jb">'+(index+1)+'</span>'
					            +'  <p class="pb-3 mb-0 small lh-sm border-bottom">'
					            +'    <a class="a_none" target="_blank" href="'+value['url']+'"><strong class="d-block text-gray-dark">'+value['name']+'</strong>'+value['description']
					            +'  </a></p>'
					            +'</div>'
						        

							});
							poc_html=poc_html==""?"<center>无poc指纹命中</center>":poc_html
				    		poc.html(poc_html)
				    		if (data.status==0) {
								//缓存起来，不要每次都请求
								var myDictionary = {};
								myDictionary[web_key+"zhiwen_html"] = zhiwen_html;
								myDictionary[web_key+"poc_html"] = poc_html;
								chrome.storage.local.set(myDictionary, function() {
							        // console.log('缓存成功',myDictionary);
							    });
				    		}
				    		if (data['data']["re_count"]!=-2) {
				    			$(".data-c-number").html(data['data']["re_count"])
				    		}
				    		// data['data']["data_version"]="有新的版本可以更新：<a href='https://www.ddpoc.com' target='_blank'>v0.2</a>"
				    		if (data['data']["data_version"]) {
			    				$(".data-version").show().html(data['data']["data_version"])
				    		}
							// 处理成功的响应
						},
						error: function(error) {
							console.error('Error:', error);
							// 处理错误的响应
			    			zhiwen.html("<center style='color:red'>检测错误，请关闭插件，再刷新网页重新打开插件重试</center>")
			    			poc.html("")
							return true
						}
			      	});
	  			}
		    });
		   
		    

	  	});
       
	});
})
